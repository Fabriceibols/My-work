# E commerce With Codeigniter 3.0

 ===>          using codeigniter 3 back/end
 ===>          using bootstrap front/end
 ===>          using font-awesome front/end
 check out to live test : http://xcode.ae/commercial/
# Requirements
PHP 5.4.0 or later
#NOTE : if you have php 7 it wii not working as fine  ,
# Installation
<hr>
# Step 1 :

Create database "shop-online" and  import shop-omline.sql to your database
<hr>
# Step 2 :
if you use wammp server create file " shop online "  inside WWW 
or if you use xampp create file " shop online " inside htdocs 
<hr>
# Step 3 :
application => config = > config.php

edit  $config['base_url'] = ' your localhost ' ;

application => config = > database.php

edit          'hostname' => 'your localhost',
              'username' => 'root',
	'password' => ''
<hr>
# Related

If you want to install CodeIgniter via Composer, check it.</br>

https://github.com/kenjis/codeigniter-composer-installer</br>
If you want a commnad line tool, check it.</br>

https://github.com/kenjis/codeigniter-cli
