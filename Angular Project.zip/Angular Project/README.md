# 4-Sure: Practical Assessment Angular

## Problem statement:
The company requires you to create a configurable custom form control dropdown / select box that can be implemented in any Angular (8 or 9) application for multiple different clients. Data bindings should allow for both predefined and observable iterable lists.

The company wants to avoid using any external styling libraries like ngMaterial or Bootstrap as they have an internal team of UX designers. 

## Do not make use of any external libraries or components!

## How to set up your assessment:
1) Request access from your 4-Sure representative.
2) Navigate to https://gitlab.com/4SureDeveloper/angular-assessment 
3) Clone the project.
4) Create a branch from master using the following pattern “your name"-"your surname” (Make all of your changes on this branch).
5) Merge “updated-lists” branch into your branch.
6) Add all of your code as required to the multiselect component and push any changes back to your branch.

## Configuration requirements:
1) Single or multiple selection
2) Close on select (allow for turning on and off)
3) Search functionality (allow for turning on and off)
4) Select / Deselect All (allow for turning on and off)

## Bonus Functionality: 
1) Form Validation for required.
2) Angular Portals
3) Inherited SCSS colors from a variables.scss file

## Skills to be tested:
1) Ability to follow instructions
2) GIT Branching and Merging
3) Angular custom form controls
4) SCSS Styling
5) Problem solving


# AngularAssessment

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 9.1.6.

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.
