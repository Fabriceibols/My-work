import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Observable, of } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit {
  title = `Angular Project - Drop Down`;
  fullForm: FormGroup;

  preferedProgrammingLanguage: string;
  preferedJavaScriptFrameworks: string[];

  ProgrammingLanguages: Observable<string[]> = of([
    'C',
    'C++',
    'C#',
    'Java',
    'VB',
    'Python',
    'Javascript',
    'Typescript',
  ]);
  JavaScriptFrameworks: Observable<string[]> = of([
    'vueJS',
    'AngularJS',
    'EmberJS',
    'BackboneJS',
    'ReactJS',
  ]);

  constructor() {}

  ngOnInit(): void {
    this.fullForm = new FormGroup({
      searchSingleEnabled: new FormControl(false, Validators.required),
      collapseOnSelect: new FormControl(false, Validators.required),
      singleSelect: new FormControl([], Validators.required),

      searchMultiEnabled: new FormControl(false, Validators.required),
      selectAllEnabled: new FormControl(false, Validators.required),
      multiSelect: new FormControl([], Validators.required),
    });
  }
}
