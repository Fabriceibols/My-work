import {
  Component,
  OnInit,
  forwardRef,
  OnChanges,
  Input,
  Output,
  EventEmitter,
  HostListener,
  SimpleChanges,
} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';

@Component({
  selector: 'app-multiselect',
  templateUrl: './multiselect.component.html',
  styleUrls: ['./multiselect.component.scss'],
  providers: [
    {
      provide: NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => MultiselectComponent),
      multi: true,
    },
  ],
})
export class MultiselectComponent
  implements ControlValueAccessor, OnInit, OnChanges {
  // tslint:disable-next-line: variable-name
  public _value: any;
  public disabled: boolean;

  public selectedItems = {};

  @Input() options: any = [];
  @Input() multiple = false;
  @Input() toggleDropdown = false;
  @Input() search = false;
  @Input() searchOnKey: string = null;
  @Input() clearOnSelection = false;
  @Input() collapseOnSelect = true;
  @Input() selectAll = false;

  @Input() displayKey = 'label';
  @Input() itemIdKey = 'value';
  @Input() placeholder = 'Select';

  /**s
   * Event emitted when search text changes.
   */
  @Output() public searchChange: EventEmitter<any> = new EventEmitter();

  /**
   * change event when value changes to provide user to handle things in change event
   */
  @Output() public change: EventEmitter<any> = new EventEmitter();

  /**s
   * Event emitted when dropdown is open.
   */
  @Output() public open: EventEmitter<any> = new EventEmitter();

  /**
   * Event emitted when dropdown is closed.
   */
  @Output() public close: EventEmitter<any> = new EventEmitter();

  selectedDisplayText = 'Select';
  searchText: string;
  clickedInside = false;
  showNotFound = false;
  allSelected = false;

  onTouched: any = () => {};
  onChanged: any = () => {};

  get value() {
    return this._value;
  }

  set value(val) {
    this._value = val;
    this.onChanged(val);
    this.onTouched();
  }

  @HostListener('click')
  public clickInsideComponent() {
    this.clickedInside = true;
  }

  @HostListener('document:click')
  public clickOutsideComponent() {
    if (!this.clickedInside) {
      this.toggleDropdown = false;
      // clear search on close
      this.searchText = null;
      this.close.emit();
    }
    this.clickedInside = false;
  }

  ngOnInit(): void {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.options && changes.options.currentValue) {
      if (
        Array.isArray(changes.options.currentValue) &&
        changes.options.currentValue.length > 0 &&
        typeof this.options[0] !== 'object'
      ) {
        this.options = changes.options.currentValue.map((option) => ({
          label: option,
          value: option,
        }));
      }
    }
  }

  writeValue(value: any, internal?: boolean): void {
    if (value) {
      if (Array.isArray(value)) {
        if (this.multiple) {
          this.value = value;
        } else {
          this.value = value[0];
        }
      } else {
        this.value = value;
      }

      if (Object.keys(this.selectedItems).length === 0) {
        if (Array.isArray(value)) {
          this.selectedItems = value.map((t) => ({ [t.value]: t }));
        } else {
          this.selectedItems[value[this.itemIdKey]] = value;
        }
        this.initializeDropdownValuesAndOptions();
      }
    } else {
      if (!internal) {
        this.reset();
      }
    }
    if (!internal) {
      this.reset();
    }
  }

  registerOnChange(fn: any): void {
    this.onChanged = fn;
  }

  registerOnTouched(fn: any): void {
    this.onTouched = fn;
  }

  setDisabledState(isDisabled: boolean): void {
    this.disabled = isDisabled;
  }

  initializeDropdownValuesAndOptions() {
    if (this.value !== '' && typeof this.value !== 'undefined') {
      if (Array.isArray(this.value)) {
        this.selectedItems = this.value.map((t) => ({ [t.value]: t }));
      } else {
        this.selectedItems[this.value[this.itemIdKey]] = this.value;
      }
    }
    this.setSelectedDisplayText();
  }

  reset() {
    this.selectedItems = {};
    // TODO: this.availableItems = [...this.options.sort(this.config.customComparator)];
    this.initializeDropdownValuesAndOptions();
  }

  /** Toggle Dropdown */
  toggleSelectDropdown() {
    this.toggleDropdown = !this.toggleDropdown;
    if (this.toggleDropdown) {
      this.open.emit();
    } else {
      this.searchText = null;
      this.close.emit();
    }
  }

  /** Searching */
  public searchTextChanged() {
    this.searchChange.emit(this.searchText);
  }

  public changeSearchText($event) {
    $event.stopPropagation();
  }

  /** Selection */
  toggleSelectAll() {
    this.allSelected = !this.allSelected;
    if (this.allSelected) {
      this.selectedItems = Object.assign(
        {},
        ...this.options.map((option) => ({ [option[this.itemIdKey]]: option }))
      );
    } else {
      this.selectedItems = {};
    }
    this.valueChanged();
  }

  toggleSelection(item) {
    if (this.selectedItems[item[this.itemIdKey]]) {
      this.deselectItem(item);
    } else {
      this.selectItem(item);
    }
  }

  selectItem(item: any) {
    this.selectedItems[item[this.itemIdKey]] = item;

    if (!this.multiple) {
      this.selectedItems = {};
      if (this.collapseOnSelect) {
        this.toggleDropdown = false;
      }
    }

    this.options.forEach((el: any, i: number) => {
      if (item === el) {
        this.selectedItems[item[this.itemIdKey]] = item;
      }
    });

    if (this.clearOnSelection) {
      this.searchText = null;
    }

    this.valueChanged();
  }

  deselectItem(item: any) {
    this.selectedItems[item[this.itemIdKey]] = undefined;
    delete this.selectedItems[item[this.itemIdKey]];
    this.valueChanged();
  }

  valueChanged() {
    this.writeValue(Object.values(this.selectedItems), true);
    this.change.emit({ value: this.value });
    this.setSelectedDisplayText();
  }

  setSelectedDisplayText() {
    const firstObject = this.selectedItems[Object.keys(this.selectedItems)[0]];
    let text: string = firstObject;

    if (typeof firstObject === 'object') {
      text = firstObject[this.displayKey];
    }

    if (this.multiple && Object.keys(this.selectedItems).length > 0) {
      if (typeof firstObject === 'object') {
        text = Object.values(this.selectedItems)
          .map((item) => item[this.displayKey])
          .join(', ');
      }

      this.selectedDisplayText = text;
    } else {
      this.selectedDisplayText =
        Object.keys(this.selectedItems).length === 0 ? this.placeholder : text;
    }
  }
}
