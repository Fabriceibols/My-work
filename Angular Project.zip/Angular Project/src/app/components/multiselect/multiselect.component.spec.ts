import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiselectComponent } from './multiselect.component';
import { FormsModule } from '@angular/forms';

const options = [
  'C',
  'C++',
  'C#',
  'Java',
  'VB',
  'Python',
  'Javascript',
  'Typescript',
];

describe('MultiselectComponent', () => {
  let component: MultiselectComponent;
  let fixture: ComponentFixture<MultiselectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MultiselectComponent],
      imports: [FormsModule],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiselectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Should register registerOnChange', () => {
    const func = () => {
      return;
    };
    component.registerOnChange(func);
    expect(component.onChanged).toEqual(func);
  });

  it('Should register registerOnTouched', () => {
    const fun = () => {
      return;
    };
    component.registerOnTouched(fun);
    expect(component.onTouched).toEqual(fun);
  });

  it('Should emit the searched text using changed event', () => {
    spyOn(component.searchChange, 'emit');
    (component as any).searchTextChanged();
    expect(component.searchChange.emit).toHaveBeenCalled();
  });

  describe('Initilization and Writing Value', () => {
    it('Should not have any options when options are not passed ', () => {
      const undefinedOptions = undefined;
      component.options = undefinedOptions;
      component.ngOnInit();
      expect(component.options).toEqual(undefined);
    });

    it('Should populate the value on initilization when value is passed', () => {
      component.value = options[0];
      (component as MultiselectComponent).initializeDropdownValuesAndOptions();
      expect(Object.values(component.selectedItems)).toEqual([options[0]]);
    });
  });

  describe('Should display text', () => {
    it('Should set the select text with 0 selected items', () => {
      (component as any).setSelectedDisplayText();
      expect(component.selectedDisplayText).toEqual('Select');
    });

    it('Should set the display text for selected items', () => {
      component.selectedItems = {
        ['C++']: {
          label: 'C++',
          value: 'C++',
        },
      };
      (component as any).setSelectedDisplayText();
      expect(component.selectedDisplayText).toEqual('C++');
    });

    it('Should set the display text with 1 object as selected item when multiple is false', () => {
      component.selectedItems = {
        ['C++']: {
          label: 'C++',
          value: 'C++',
        },
      };
      component.multiple = false;
      (component as any).setSelectedDisplayText();
      expect(component.selectedDisplayText).toEqual('C++');
    });
  });

  describe('Selection', () => {
    it('Should select an item items with multiple true', () => {
      component.multiple = true;
      component.selectItem(options[1]);
      expect(Object.values(component.selectedItems)).toEqual([options[1]]);
    });

    it('Should set the value', () => {
      component.multiple = true;
      component.selectedItems = {
        ['C']: {
          label: 'C',
          value: 'C',
        },
        ['C++']: {
          label: 'C++',
          value: 'C++',
        },
      };
      component.valueChanged();
      console.log(component.value);
      expect(component.value).toEqual([
        { label: options[0], value: options[0] },
        { label: options[1], value: options[1] },
      ]);
    });

    it('Should set the selected text for multi select', () => {
      component.multiple = true;
      component.selectedItems = {
        ['C']: {
          label: 'C',
          value: 'C',
        },
        ['C++']: {
          label: 'C++',
          value: 'C++',
        },
      };
      component.valueChanged();
      expect(component.selectedDisplayText).toEqual(
        [options[0], options[1]].map((t) => t).join(', ')
      );
    });

    it('Should set the selected text for single select with string options', () => {
      component.selectedItems = { [1]: options[0] };
      component.valueChanged();
      expect(component.selectedDisplayText).toEqual(options[0]);
    });

    it('Should set the selected text for single select when nothing selected', () => {
      component.selectedItems = {};
      component.valueChanged();
      expect(component.selectedDisplayText).toEqual('Select');
    });
  });
});
