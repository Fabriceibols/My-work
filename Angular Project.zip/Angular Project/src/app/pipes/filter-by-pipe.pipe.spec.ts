import { FilterByPipePipe } from './filter-by-pipe.pipe';

describe('FilterByPipePipe', () => {
  it('create an instance', () => {
    const pipe = new FilterByPipePipe();
    expect(pipe).toBeTruthy();
  });
});
