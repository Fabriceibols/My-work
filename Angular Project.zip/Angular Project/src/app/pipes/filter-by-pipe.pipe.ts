import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterBy',
})
export class FilterByPipePipe implements PipeTransform {
  transform(array: any[], searchText?: string, keyName?: string) {
    if (!array || !searchText || !Array.isArray(array)) {
      return array;
    }

    if (typeof array[0] === 'string') {
      return array.filter(
        (item: string) =>
          item.toLocaleLowerCase().indexOf(searchText.toLocaleLowerCase()) > -1
      );
    }

    if (!keyName) {
      return array.filter((item: any) => {
        for (const key in item) {
          if (
            typeof item[key] !== 'object' &&
            item[key]
              .toString()
              .toLocaleLowerCase()
              .indexOf(searchText.toLocaleLowerCase()) > -1
          ) {
            return true;
          }
        }
        return false;
      });
    } else {
      return array.filter((item: any) => {
        if (
          typeof item[keyName] !== 'object' &&
          item[keyName]
            .toString()
            .toLocaleLowerCase()
            .indexOf(searchText.toLocaleLowerCase()) > -1
        ) {
          return true;
        }
        return false;
      });
    }
  }
}
