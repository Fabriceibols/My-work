import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MultiselectComponent } from './components/multiselect/multiselect.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FilterByPipePipe } from './pipes/filter-by-pipe.pipe';

@NgModule({
  declarations: [AppComponent, MultiselectComponent, FilterByPipePipe],
  imports: [BrowserModule, AppRoutingModule, FormsModule, ReactiveFormsModule],
  providers: [],
  bootstrap: [AppComponent],
})
export class AppModule {}
